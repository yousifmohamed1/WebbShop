
package Uppgift2;

import javax.lang.model.element.Name;
import java.util.Scanner;

/*public class Main {
    public static void main(String[] args) {

    }
        private static void splitwords(String str) {
            String words[]=str.split(" ");
            for(int i =0; i<words.length; i++){
                String s= words[i];
                System.out.println(s.charAt(i));

        Scanner scanner= new Scanner(System.in);



        System.out.println("What is your firstname");
        String text2= scanner.nextLine();
        System.out.println("What is your last name");
        String text3= scanner.nextLine();
        System.out.println("Your name is"+" "+text2+", "+text3+ " "+",Hej");

       // boolean name= "
                String name = null;
                if (name.charAt(0) == text2 ) {
                    if (text3) {
                        System.out.println("Both for and last name begin with the same letter starting with");

                    } else {
                        System.out.println();


                    }
                } else {
                    System.out.println();


                }
            }
                private static void splitwords(String str) {
                    String words[]=str.split(" ");
                    for(int i =0; i<words.length; i++){
                        String s= words[i];
                        System.out.println(s.charAt(i));


    }
} */
