package Uppgift4;

import jdk.internal.access.JavaIOFileDescriptorAccess;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;



public class CountTotalPointss {
    public static void CountTotalPoints(String[] args) {
        for (int i=1; i<=6;i++) {

         //  if (facit.get(i).contains(answers.get(i))){

            }
        }

    public static void PrintResult() {
        new CountTotalPointss();

        int CountTotalPoints = 0;

        if( CountTotalPoints == 6) {
            System.out.println("du har alla rätt!!");
        } else {
            System.out.println("Du behöver nog studera lite mer....");
        }
    }
    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);
        int totalPoints = 0;
        Map<Object, Object> facit = new HashMap<>();
        facit.put(1, List.of("Scrum Product Owner"));
        facit.put(2, List.of("Standup"));
        facit.put(3, List.of("2010"));
        facit.put(4, List.of("No"));
        facit.put(5, List.of("Coaching to be able to work independently" +
                "Help your team create something with high value" +
                " " + "Remove obstacles and blockages that keep your team from moving forward"));
        facit.put(6, List.of("4 hours"));

        HashMap<Object, Object> answers = new HashMap<>();

        System.out.println("1.Who owns the backlog? ");
        String answer1 = scanner.nextLine();
        answers.put(1, answer1.toLowerCase());

        System.out.println("2. What is another word for Daily Scrum?");
        String answer2 = scanner.nextLine();
        answers.put(2, answer2.toLowerCase());

        System.out.println("3. What year was Scrum Guiden first released?");
        String answer3 = scanner.nextLine();
        answers.put(3, answer3.toLowerCase());

        System.out.println("4. Are the different titles of the developers within a development team in Scrum?");
        String answer4 = scanner.nextLine();
        answers.put(4, answer4.toLowerCase());

        System.out.println("5. What are Scrum masters tasks?");
        String answer5 = scanner.nextLine();
        answers.put(5, answer5.toLowerCase());

        System.out.println("6.How long should a Sprint plan be for a 2 week sprint ?");
        String answer6 = scanner.nextLine();
        answers.put(6, answer6.toLowerCase());


        printResult();
    }

    private static void printResult() {
    }
}


