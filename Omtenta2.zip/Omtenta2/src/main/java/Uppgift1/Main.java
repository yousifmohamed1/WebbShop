package Uppgift1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner= new Scanner(System.in);

        System.out.println("What is your firstname");
        String text2= scanner.nextLine();
        System.out.println("What is your last name");
        String text3= scanner.nextLine();
        System.out.println("Your name is"+" "+text2+", "+text3+ " "+",Hej");





    }
}
