package Uppgift3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Jag fick problem med att få mina 3 NextLine att bli gröna och därför
 * så har jag kommentera bort koden så de inte förstör och så att du ska kunna
 * åtminstone se hur jag har tänkt.
 */

/*public class Main {

    private static Uppgift3.Movie[] Movie;

    public static void main(String[] args) {
        Scanner scanner= new Scanner(System.in);

        int input =0;

        // Movie = new ArrayList<>();

        List<Movie> animals= new ArrayList<>();
    }

    private static void printInformation() {
        for (Movie m : Movie) {
            System.out.println(m.getTitle() + " " + m.getLength()+ " "+ m.getMainActor());
           // System.out.println(m.getFirstName() + "s favoritfilm är: " + m.getFavouriteMovie());
            System.out.println("-----");
        }
    }

            private static void createNewMovie() {
        Scanner scanner=new Scanner(System.in);

               Movie movie= new Movie();
                System.out.println("what is the title of the movie?");
                String title = Scanner.Nextline();
                movie.setTitle(title);
                System.out.println("What is the length of the movie?");
                String length= Scanner.nextLine();
               movie.setLength(length);
                System.out.println("Who is the MainActor?");
                String mainactor=scanner.nextLine();
                movie.setMainActor(mainactor);

                movie.add(movie);

                System.out.println("""
                    Do you want to create another Movie?
                    1. Yes
                    2.  No, I'm done
                    """);
                int input = Integer.parseInt(Scanner.NextLine());
            }
        } */

