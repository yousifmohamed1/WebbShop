package Uppgift3;

public class Movie {
    String title;
    String length;
    String mainActor;

    public Movie(String title, String length, String mainActor) {
        this.title = title;
        this.length = length;
        this.mainActor = mainActor;
    }

    public Movie() {

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getMainActor() {
        return mainActor;
    }

    public void setMainActor(String mainActor) {
        this.mainActor = mainActor;
    }

    public void add(Movie movie) {
    }
}
